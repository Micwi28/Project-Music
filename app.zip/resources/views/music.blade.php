@extends('layouts.main')
@section('title', 'Daftar Mobil')
@section('artikel')
    <div class="card">
        <div class="card-header">
            <div class="float-left">
                <a href="music/add-form" class="btn btn-primary"><i class="bi bi-plus-square"></i> Add Music</a>
            </div>
        </div>
        <div class="card-body">
            @if(session('alert'))
                <strong>{{session('alert')}}</strong>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>{{session('alert')}}</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            @endif
            <!--Tabel Disini-->
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Genre</th>
                        <th>Penyanyi</th>
                        <th>Composser</th>
                        <th>Rilis</th>
                        <th>Poster</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($mv as $idx =>$m)
                        <tr>
                            <td>{{ $idx+1 }}</td>
                            <td>{{ $m->judul}}</td>
                            <td>{{ $m->genre}}</td>
                            <td>{{ $m->penyanyi}}</td>
                            <td>{{ $m->composser}}</td>
                            <td>{{ $m->tahun}}</td>
                            <td>
                                @if ($m->poster)
                                    <img src="{{ asset('/storage/'.$m->poster) }}"  
                                    alt = "{{ $m->poster}}" height="80" width="120">
                                    @else
                                    <img src="/storage/poster/no-image.png"
                                    alt = "No Image" height="80" width="120">
                                @endif
                            </td>
                            <td>
                                <a href="/music/edit-form/{{$m->id}}" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                                <a href="/delete/{{$m->id}}" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                    @endforeach    
                </tbody>
            </table>
        </div>
    </div>
@endsection