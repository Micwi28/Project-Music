@extends('layouts.main')
@section('title', 'settings')
@section('artikel')
    <h1>Settings</h1>
    <p>Ini adalah halaman settings</p>
@endsection