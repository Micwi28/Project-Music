@extends('layouts.main')
@section('title', 'Form Edit Music')
@section('artikel')
    <div class="card">
        <div class="card-head"></div>
        <div class="card-body">
            <!--Form Add Music Disini-->
            <form action="/update/{{$mv->id}}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="form-group">
                        <label>Judul</label>
                        <input type="text" name="judul" class="form-control" value="{{$mv->judul}}" required>
                    </div>
                    <div class="form-group">
                        <label>Genre Musik</label>
                        <select name="genre" class="form-control">
                            <option value="0"> --Pilih Genre-- </option>
                            <option value="POP" {{($mv->genre=="POP") ? "selected":""}}>POP</option>
                            <option value="Rock" {{($mv->genre=="Rock") ? "selected":""}}>Rock</option>
                            <option value="Jazz" {{($mv->genre=="Jazz") ? "selected":""}}>Jazz</option>
                            <option value="R&B" {{($mv->genre=="R&B") ? "selected":""}}>R&B</option>
                            <option value="Country" {{($mv->genre=="Country") ? "selected":""}}>Country</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Penyanyi</label>
                        <input type="text" name="penyanyi" class="form-control" value="{{$mv->penyanyi}}" required>
                    </div>
                    <div class="form-group">
                        <label>Composser</label>
                        <select name="composser" class="form-control">
                            <option value="0"> --Pilih Composser-- </option>
                            <option value="VEVO" {{($mv->composser=="VEVO") ? "selected":""}}>VEVO</option>
                            <option value="Musica Studios" {{($mv->composser=="Musica Studios") ? "selected":""}}>Musica Studios</option>
                            <option value="Cassiopeia" {{($mv->composser=="Cassiopeia") ? "selected":""}}>Cassiopeia</option>
                            <option value="Wish 107.5" {{($mv->composser=="Wish 107.5") ? "selected":""}}>Wish 107.5</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tahun</label>
                        <input type="number" min="1900" max="2100" name="tahun" class="form-control" value="{{$mv->tahun}}" readonly required>
                    </div>
                    <div class="form-group">
                        @if ($mv->poster)
                            <img src="{{ asset('/storage/'.$mv->poster) }}"  
                            alt = "{{ $mv->poster}}" height="80" width="120">
                            @else
                            <img src="/storage/poster/no-image.png"
                            alt = "No Image" height="80" width="120">
                        @endif
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                    </div>
            </form>
        </div>
    </div>
@endsection