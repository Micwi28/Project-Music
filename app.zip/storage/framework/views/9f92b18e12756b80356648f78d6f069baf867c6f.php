<?php $__env->startSection('title', 'Daftar Mobil'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card">
        <div class="card-header">
            <div class="float-left">
                <a href="car/add-form" class="btn btn-primary"><i class="bi bi-plus-square"></i> Add Car</a>
            </div>
        </div>
        <div class="card-body">
            <?php if(session('alert')): ?>
                <strong><?php echo e(session('alert')); ?></strong>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('alert')); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            <?php endif; ?>
            <!--Tabel Disini-->
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kategori</th>
                        <th>Nama</th>
                        <th>Merek</th>
                        <th>Tahun</th>
                        <th>Harga</th>
                        <th>Poster</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx =>$m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($idx+1); ?></td>
                            <td><?php echo e($m->kategori); ?></td>
                            <td><?php echo e($m->nama); ?></td>
                            <td><?php echo e($m->merek); ?></td>
                            <td><?php echo e($m->tahun); ?></td>
                            <td>Rp <?php echo e(number_format($m->harga, 0, '', '.')); ?></td>
                            <td>
                                <?php if($m->poster): ?>
                                    <img src="<?php echo e(asset('/storage/'.$m->poster)); ?>"  
                                    alt = "<?php echo e($m->poster); ?>" height="80" width="120">
                                    <?php else: ?>
                                    <img src="/storage/poster/no-image.png"
                                    alt = "No Image" height="80" width="120">
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="/car/edit-form/<?php echo e($m->id); ?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                                <a href="/delete/<?php echo e($m->id); ?>" class="btn btn-danger"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Aplication Car\resources\views/car.blade.php ENDPATH**/ ?>