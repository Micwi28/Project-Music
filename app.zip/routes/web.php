<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::group(['middleware' => ['guest']], function(){
    Route::get("/", "PageController@login")->name('login');
    Route::post("/login", "AuthController@ceklogin");
});

Route::group(['middleware' => ['auth']], function(){
    Route::get("/user", "PageController@formedituser");
    Route::post("/updateuser", "PageController@updateuser");
    Route::get("/logout","AuthController@ceklogout");

    Route::get("/home", "PageController@home");
    Route::get("/music", "PageController@music");
    Route::get("/music/add-form", "PageController@addformmusic");
    Route::post("/save", "PageController@savemusic");
    Route::get("/music/edit-form/{id}", "PageController@editformmusic");
    Route::put("/update/{id}","PageController@updatemusic");
    Route::get("/delete/{id}","PageController@deletemusic");
    Route::get("/messages", "PageController@messages");
});
