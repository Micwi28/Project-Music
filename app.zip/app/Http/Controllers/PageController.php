<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Music;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    public function home()
    {
        return view("home", ["key" => "home"]);
    }

    public function messages()
    {
        return view("messages", ["key" => "messages"]);
    }

    public function music()
    {
        $music = Music::orderBy('id', 'desc')->get();
        return view("music", ["key" => "music", "mv"=> $music]);
    }

    public function addformmusic()
    {
        return view("form-add", ["key" => "music"]);
    }

    public function savemusic(Request $request)
    {
        $file_name = time().'-'.$request->file('poster')->getClientOriginalName();
        // return $file_name;
        $path = $request->file('poster')->storeAs('poster', $file_name,'public');

        Music::create([
            'judul'     => $request->judul,
            'genre'     => $request->genre,
            'penyanyi'  => $request->penyanyi,
            'composser' => $request->composser,
            'tahun'     => $request->tahun,
            'poster'    => $path
        ]);
        return redirect('/music')->with('alert', 'Data Berhasil Disimpan');
    }

    public function editformmusic($id)
    {
        $music = Music::find($id);
        return view('form-edit', [
            "key" => "music",
            'mv' => $music
        ]);
    }

    public function updatemusic(Request $request, $id)
    {
        $music = Music::find($id);

        $music->judul = $request->judul;
        $music->genre = $request->genre;
        $music->penyanyi = $request->penyanyi;
        $music->composser = $request->composser;
        $music->tahun = $request->tahun;
        if ($request->poster)
        {
            if($music->poster)
            {
                Storage::disk('public')->delete($music->poster);
            }
            $file_name = time().'-'.$request->file('poster')->getClientOriginalName(); //mengubah nama file
            $path = $request->file('poster')->storeAs('poster', $file_name,'public'); //simpan file ke folder public
            $music->poster=$path; //simpan path ke database
        }
        $music->save(); //simpan data
        return redirect('/music')->with('alert', 'Data Berhasil Diupdate');
    }

    public function deletemusic($id)
    {
        $music = Music::find($id);
        if($music->poster)
        {
            Storage::disk('public')->delete($music->poster);
        }
        $music->delete();
        return redirect('/music')->with('alert', 'Data Berhasil Dihapus');
    }

    public function login()
    {
        return view("login");
    }

    public function formedituser(){
        return view("formedituser", ["key"=>"edit_user"]);
    }

    public function updateuser(Request $request){
        if($request->password_baru == $request->konfirmasi_password){
            $user = Auth::user();
            $user -> password = bcrypt($request -> password_baru);
            $user -> save();
            return redirect("/user")->with("info", "Password Berhasil Diubah");
        }
        else{
            return redirect("/user")->with("info", "Password Gagal Diubah");
        }
    }
}
