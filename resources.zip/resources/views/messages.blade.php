@extends('layouts/main')
@section('title', 'messages')
@section('artikel')
    <h1>Messages</h1>
    <p>Messages.</p>
@endsection