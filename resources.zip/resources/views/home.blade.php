@extends('layouts/main')
@section('title', 'home')
@section('artikel')
    <h1>HOME</h1>
    <p>Web ini berguna untuk mempelajari dari matakuliah Perancangan Berbasis Web, baik secara teori ataupun praktikum.</p>
@endsection