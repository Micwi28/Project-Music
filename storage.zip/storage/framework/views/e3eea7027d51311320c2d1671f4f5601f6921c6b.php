<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection('artikel'); ?>
    <h1>HOME</h1>
    <p>Web ini berguna untuk mempelajari dari matakuliah Perancangan Berbasis Web, baik secara teori ataupun praktikum.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\WebMovies\resources\views/layouts/home.blade.php ENDPATH**/ ?>