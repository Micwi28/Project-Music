<?php $__env->startSection('title', 'massages'); ?>
<?php $__env->startSection('artikel'); ?>
    <h1>Massages</h1>
    <p>Ini adalah halaman massages</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\WebMovies\resources\views/layouts/massages.blade.php ENDPATH**/ ?>