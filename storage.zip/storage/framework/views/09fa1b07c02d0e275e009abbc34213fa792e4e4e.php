<?php $__env->startSection('title', 'Form Edit Music'); ?>
<?php $__env->startSection('artikel'); ?>
    <div class="card">
        <div class="card-head"></div>
        <div class="card-body">
            <!--Form Add Music Disini-->
            <form action="/update/<?php echo e($mv->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                        <label>Judul</label>
                        <input type="text" name="judul" class="form-control" value="<?php echo e($mv->judul); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Genre Musik</label>
                        <select name="genre" class="form-control">
                            <option value="0"> --Pilih Genre-- </option>
                            <option value="POP" <?php echo e(($mv->genre=="POP") ? "selected":""); ?>>POP</option>
                            <option value="Rock" <?php echo e(($mv->genre=="Rock") ? "selected":""); ?>>Rock</option>
                            <option value="Jazz" <?php echo e(($mv->genre=="Jazz") ? "selected":""); ?>>Jazz</option>
                            <option value="R&B" <?php echo e(($mv->genre=="R&B") ? "selected":""); ?>>R&B</option>
                            <option value="Country" <?php echo e(($mv->genre=="Country") ? "selected":""); ?>>Country</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Penyanyi</label>
                        <input type="text" name="penyanyi" class="form-control" value="<?php echo e($mv->penyanyi); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Composser</label>
                        <select name="composser" class="form-control">
                            <option value="0"> --Pilih Composser-- </option>
                            <option value="VEVO" <?php echo e(($mv->composser=="VEVO") ? "selected":""); ?>>VEVO</option>
                            <option value="Musica Studios" <?php echo e(($mv->composser=="Musica Studios") ? "selected":""); ?>>Musica Studios</option>
                            <option value="Cassiopeia" <?php echo e(($mv->composser=="Cassiopeia") ? "selected":""); ?>>Cassiopeia</option>
                            <option value="Wish 107.5" <?php echo e(($mv->composser=="Wish 107.5") ? "selected":""); ?>>Wish 107.5</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tahun</label>
                        <input type="number" min="1900" max="2100" name="tahun" class="form-control" value="<?php echo e($mv->tahun); ?>" readonly required>
                    </div>
                    <div class="form-group">
                        <?php if($mv->poster): ?>
                            <img src="<?php echo e(asset('/storage/'.$mv->poster)); ?>"  
                            alt = "<?php echo e($mv->poster); ?>" height="80" width="120">
                            <?php else: ?>
                            <img src="/storage/poster/no-image.png"
                            alt = "No Image" height="80" width="120">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                    </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Aplication Music\resources\views/form-edit.blade.php ENDPATH**/ ?>