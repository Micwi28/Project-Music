    <?php $__env->startSection('title', 'Form Add Music'); ?>
    <?php $__env->startSection('artikel'); ?>
        <div class="card">
            <div class="card-head"></div>
            <div class="card-body">
                <!--Form Add Music Disini-->
                <form action="/save" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Judul</label>
                        <input type="text" name="judul" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Genre Musik</label>
                        <select name="genre" class="form-control">
                            <option value="0"> --Pilih Genre-- </option>
                            <option value="POP">POP</option>
                            <option value="Rock">Rock</option>
                            <option value="Jazz">Jazz</option>
                            <option value="R&B">R&B</option>
                            <option value="Country">Country</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Penyanyi</label>
                        <input type="text" name="penyanyi" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Composser</label>
                        <select name="composser" class="form-control">
                            <option value="0"> --Pilih Composser-- </option>
                            <option value="VEVO">VEVO</option>
                            <option value="Musica Studios">Musica Studios</option>
                            <option value="Cassiopeia">Cassiopeia</option>
                            <option value="Wish 107.5">Wish 107.5</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tahun</label>
                        <input type="number" min="1900" max="2100" name="tahun" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Poster</label>
                        <input type="file" name="poster" class="form-control-file" accept="image/*">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">SIMPAN</button>
                    </div>
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\Aplication Music\resources\views/form-add.blade.php ENDPATH**/ ?>